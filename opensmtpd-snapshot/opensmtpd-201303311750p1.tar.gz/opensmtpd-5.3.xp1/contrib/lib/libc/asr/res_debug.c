/*	$OpenBSD: res_debug.c,v 1.1 2012/09/08 11:08:21 eric Exp $	*/
/* NOTHING */
